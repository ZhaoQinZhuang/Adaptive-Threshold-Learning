
import itertools

import pandas as pd
import numpy as np
from tools import plot, DFS, dataProcess, readdata, labelsGen

image_path1 = 'picture/comPicture.png'
dataPath = 'D:\\file\\研究生\\科研\\experiment\\data4Nodes\\data0.csv'
def initEdge(dicts,lag1,lag2,n):
    dictfs,dictfe,dictos,dictoe = dicts
    # 字典初始化
    for i in range(n):
        for j in range(n):
            # 正向0延迟
            if i != j:
                if str(i) + '-0' not in dictfs:
                    dictfs[str(i) + '-0'] = []
                if str(j) + '-' + str(lag1) not in dictfe:
                    dictfe[str(j) + '-' + str(lag1)] = []
                dictfs[str(i) + '-0'].append(str(j) + '-' + str(lag1))  # 出
                dictfe[str(j) + '-' + str(lag1)].append(str(i) + '-0')  # 入
            # 反向n延迟
            if str(i) + '-0' not in dictos:
                dictos[str(i) + '-0'] = []
            if str(j) + '-' + str(lag2) not in dictoe:
                dictoe[str(j) + '-' + str(lag2)] = []
            dictos[str(i) + '-0'].append(str(j) + '-' + str(lag2))  # 出
            dictoe[str(j) + '-' + str(lag2)].append(str(i) + '-0')  # 入
def cidelete(corArray,l,dicts,lag1,lag2):
    pass
def skeleton(data,lagMax,alpha,message=0):
    print()
    dataA = data.values
    data1 = dataA.tolist()
    lagMax=3
    n,l = len(dataA[0]),len(dataA)                  #变量个数和时间序列长短
    for i in range(l-lagMax):                       #数据扩展
        for j in range(1,lagMax+1):
            data1[i] += data1[i+j]
    for i in range(lagMax):
        data1.pop(l-lagMax)
    dict1,dict2 = {},{}                             #正向学习(出，入)
    dict3,dict4 = {},{}                             #反向学习(出，入)
    alpha = [0.05] * n
    lag1,lag2 = 0,n
    dataF = pd.DataFrame(data=data1, index=None, columns=None, dtype=None, copy=False)
    corArray = dataF.corr().values                  #求相关性矩阵
    l = len(dict1)
    dicts = [dict1,dict2,dict3,dict4]
    initEdge(dicts,lag1,lag2,n) #初始化0,n延迟全连接图
    # print(dict1,'\n',dict2,'\n',dict3,'\n',dict4, file=open("D:\\file\\研究生\\科研\\experiment\\print\\初始化全连接.txt", "w"))
    while not lag1>lag2:
        cidelete(corArray,l,dicts,lag1,lag2)
        lag1+=1
        lag2-=1
def pcskeleton(dataCor, l, alpha, ci, labels, numa, message = 0, single=0, m_max = float("inf"), str1=None):
    if str1 is None:
        str1 = ['', '']
    maxC = 10
    if single:
        maxC = 0
    flag = 0
    sum = 0
    numa = list(numa)
    rate1 = [numa[0]]
    for i in range(1,len(numa)):
        sum += numa[i]
    for i in range(1,len(numa)):
        rate1.append(numa[i]/sum)
    alpha = list(alpha)
    while True:
        lagmax = int(labels[0].split('-')[-1])
        lenth = len(labels)
        varnum = int(lenth/(lagmax+1))
        sepset = [[[] for i in range(len(labels))] for i in range(len(labels))]
        lenOfLables = len(labels)
        G = [[True for i in range(lenOfLables)] for i in range(lenOfLables)]
        for i in range(lenOfLables):
            G[i][i] = False
        for i in range(lenOfLables):
            for j in range(i):
                if labels[i].split('-')[0] == labels[j].split('-')[0] and abs(int(labels[i].split('-')[1]) - int(labels[j].split('-')[1]))>1:
                    G[i][j],G[j][i] = False,False
        if message > 1:
            plot(G, labels, image_path1, name='完全图')
        notdone = True
        ord = 0  # 分离集大小
        ind = []
        for i in range(len(G)):
            for j in range(i):
                ind.append((i, j))
        while notdone and any(G) and ord <= m_max:
            notdone = False
            ind1 = list(ind)
            for x, y in ind1:
                neighborsBoolX = [row[x] for row in G]
                neighborsBoolY = [row[y] for row in G]
                neighbors = [neighborsBoolY[i] or neighborsBoolX[i] for i in range(lenOfLables)]
                neighbors[x],neighbors[y]=0,0
                Xcan = [False for i in range(lenOfLables)]
                Ycan = [False for i in range(lenOfLables)]
                DFS(G,x,y,Xcan)
                DFS(G,y,x,Ycan)
                pcSetsBool = [Xcan[i] and Ycan[i] and (neighborsBoolX[i] or neighborsBoolY[i]) for i in
                              range(lenOfLables)]
                pcSets = [i for i in range(lenOfLables) if pcSetsBool[i] == True]
                if len(pcSets) >= ord:
                    if len(pcSets) > ord:
                        notdone = True
                        for pcSets_S in set(itertools.combinations(pcSets, ord)):
                            pcSets_SL = list(pcSets_S)
                            pval = ci(dataCor, l,x, y, pcSets_SL)
                            lag = abs(int(labels[y].split('-')[1])-int(labels[x].split('-')[1]))
                            t1, t2 = str1
                            # print('******',pval,alpha[lag])
                            if pval+0.0001 >= alpha[lag]:
                                start,end,breaks = x,y,x
                                G[start][end] = G[end][start] = False
                                ind.remove((start, end))
                                sepset[start][end] = pcSets_SL

                                # print("删除了", labels[start], labels[end], "\tval值是", round(pval, 4), "\t延迟是",
                                #       lag, "alpha是", alpha[lag], "分离集是", [labels[i] for i in pcSets_SL])
                                # if True:
                                if message>0 and ((labels[start] == t1 and labels[end] == t2) or (labels[end] == t1 and labels[start]==t2)):
                                # if (labels[start] is '0-1' and labels[end] is '2-2') or (labels[start] is '0-1' and labels[end] is '2-2'):
                                    print("删除了", (labels[start], labels[end]),"\tval值是",round(pval,4),"\t延迟是",lag,"alpha是",alpha[lag],"分离集是",[labels[i] for i in pcSets_SL])
                                # while True:
                                #     if (start,end) in ind:
                                #         G[start][end] = G[end][start] = False
                                #         ind.remove((start, end))
                                #         # print("删除了", (labels[start], labels[end]),"\tval值是",round(pval,4),"\t延迟是",lag,"alpha是",alpha[lag],"分离集是",[labels[i] for i in pcSets_SL])
                                #         # print("删除了", (start, end),"\tval值是",round(pval,4),"\t延迟是",lag,"alpha是",alpha[lag],"分离集是",[labels[i] for i in pcSets_SL])
                                #         temp = [(i+varnum)%lenth for i in pcSets_SL]
                                #         pcSets_SL = temp
                                #         sepset[start][end] = pcSets_SL
                                #     start = (start + varnum)%lenth
                                #     end = (end + varnum)%lenth
                                #     if start == breaks:
                                #         break
                                break
                            else:
                                # pass
                                # print((x, y),"\tval值是",round(pval,4),"\t延迟是",lag,"alpha是",alpha[lag],"分离集是",[labels[i] for i in pcSets_SL])
                                if message>0 and ((labels[x] == t1 and labels[y] == t2) or (
                                        labels[x] == t2 and labels[y] == t1)):
                                    print((labels[x], labels[y]), "\tval值是", round(pval, 4), "\t延迟是", lag, "alpha是",
                                      alpha[lag], "分离集是", [labels[i] for i in pcSets_SL])
            ord += 1
        snuma = [0 for i in range(lagmax+1)]
        for i in range(len(G)):
            for j in range(i):
                if G[i][j]:
                    snuma[abs(int(labels[i].split('-')[1])-int(labels[j].split('-')[1]))]+=1
        sum1 = 0
        rate2 = []
        for i in range(len(snuma)):
            sum1 += snuma[i]
        for i in range(len(snuma)):
            rate2.append(snuma[i] / sum1)
        if message > 0:
            print('truelnum:\t',numa)
            print('nowlnum:\t',snuma)
            print('numrateT:\t',[round(i,3) for i in rate1])
            print('numrateN:\t',[round(i,3) for i in rate2])
            print('alpha:\t\t',[round(i,3) for i in alpha])
        flag1 = 0
        for i in range(lagmax+1):#数量估计未比较
            dif = rate1[i]-rate2[i]
            dif2 = numa[i] - snuma[i]
            # if abs(dif) > 0.1*rate1[i] and (abs(dif2)>(lagmax-i+1) or abs(dif)>rate1[i]):
            if abs(dif) > 0.01*rate1[i] and abs(dif2)>(lagmax-i+1) or i==0 or abs(dif2)>(lagmax-i+2):
            # if dif > 0.1*rate1[i] or i==0 or dif2 <-(lagmax-i+2):
                if alpha[i] == 0.001 or alpha[i] == 0.2:
                    flag1 = i
                if (dif > 0 and dif2 <0) or (dif < 0 and dif2 > 0) and abs(dif2 > (lagmax-i+2)):
                    alpha[i] = max(min(0.2,(alpha[i]-dif/3)),0.001)
                else:
                    alpha[i] = max(min(0.2,(alpha[i]+dif/3)),0.001)

        # if message >0:
        #     print('alphaC:\t\t', [round(i, 3) for i in alpha])
        #     plot(G,labels,name='骨架')
        #     print("*******************************")
        if (flag1==lagmax or flag1 == 1) and single == -1:#自动识别延迟未能实现
            sum = 0
            dataR = readdata(dataPath, message)
            lagmax, alpha, dataCorr, l, numa = dataProcess(dataR,lagmax-1)
            labels = labelsGen(len(dataR.T), lagmax + 1)
            rate1 = []
            for i in range(len(numa)):
                sum += numa[i]
            for i in range(len(numa)):
                rate1.append(numa[i] / sum)
            if message > 0:
                print('改延迟')
                print(lagmax)
            flag = 0
        if flag == maxC:
            if message > 0:
                print('alphaC:\t\t', [round(i, 3) for i in alpha])
                plot(G, labels, name='骨架')
                print("*******************************")
            return {'sk': np.array(G), 'sepset': sepset}
        flag+=1