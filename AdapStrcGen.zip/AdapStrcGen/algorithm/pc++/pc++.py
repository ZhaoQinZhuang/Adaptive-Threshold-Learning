
from functions import pcskeleton
from tools import readdata, dataProcess, labelsGen, parr_ci_test as p, ShowTrueC, value
import numpy as np


def main(dn,single,message,str1,alphas):
    message = message
    dataP = 'D:\\file\\研究生\\科研\\experiment\\data4Nodes\\'
    dataPath = dataP + 'data'+str(dn)+'.csv'
    realDAG = ShowTrueC(message,dataP)                                                    #查看真实关系
    dataR = readdata(dataPath, message)                                             #读取数据集
    lagMax,alpha,dataCorr,l,numa = dataProcess(dataR,message=message,lagMaxh=3)               #数据预处理
    if single:
        for i in range(len(alpha)):
            alpha[i] = alphas
    labels = labelsGen(len(dataR.T),lagMax+1)                                       #初始化标签
    skeleton = pcskeleton(dataCorr,l,alpha,p,labels,numa,message,single,str1=str1)  #骨架学习
    acc,pre,rec,F1 = value(realDAG,skeleton['sk'])
    print('acc',round(acc,4),'pre',round(pre,4),'rec',round(rec,4),'filenum=',dn,end=' ')
    if single:
        print('alpha=',alphas)
    else:
        print('multialpha')
    return acc,pre,rec,F1
if __name__ == '__main__':
    # for i in range(100):
    #     main(i,1)
    alphasmain =[0.2, 0.15, 0.1, 0.05, 0.01, 0.001]
    alphasa =['multi',0.2, 0.15, 0.1, 0.05, 0.01, 0.001]
    messa = -3
    # file = 20
    acc = [[] for i in range(7)]
    pre = [[] for i in range(7)]
    rec = [[] for i in range(7)]
    F1 = [[] for i in range(7)]
    for file in range(50,70):
        print('file',file,'/1000')
        accm,prem,recm,F1m = main(file, 0, messa, ['', ''], 0.1)
    #     acc[0].append(accm)
    #     pre[0].append(prem)
    #     rec[0].append(recm)
    #     F1[0].append(F1m)
    #     for i in range(6):
    #         acci,prei,reci,F1i = main(file,1,messa,['',''],alphasmain[i])
    #         acc[i+1].append(acci)
    #         rec[i+1].append(reci)
    #         pre[i+1].append(prei)
    #         F1[i+1].append(F1i)
    # print('acc',acc)
    # print('pre',pre)
    # print('rec',rec)
    # print('F1',F1)
    # for i in range(7):
    #     print('acc'+str(i)+'mean:',round(np.mean(acc[i]),5),'var:',round(np.var(acc[i]),5),'alpha:',alphasa[i])
    # print('************************')
    # for i in range(7):
    #     print('pre'+str(i)+'mean:',round(np.mean(pre[i]),5),'var:',round(np.var(pre[i]),5),'alpha:',alphasa[i])
    # print('************************')
    # for i in range(7):
    #     print('rec'+str(i)+'mean:',round(np.mean(rec[i]),5),'var:',round(np.var(rec[i]),5),'alpha:',alphasa[i])
    # print('************************')
    # for i in range(7):
    #     print('F1'+str(i)+'mean:',round(np.mean(F1[i]),5),'var:',round(np.var(F1[i]),5),'alpha:',alphasa[i])






