from tools import dataProcessNew, ShowTrueC, readdata
from functions import causalDiscovery


def main(dn,al):
    global pre1, rec1, pre2, rec2
    message = -100   #控制台输出信息冗余度
    dn =dn                              #文件编号
    path = 'D:\\科研\\实验\\10-5\\'      #数据路径
    dataPath = path + 'data' + str(dn) + '.csv'

    realDAG,trueR = ShowTrueC(message,path)  # 查看真实关系
    dataR = readdata(dataPath, message)  # 读取数据集
    a,numDis = dataProcessNew(dataR,path,dn,lagMaxh=5,message=message)#参数初始化
    print(a)
    print(numDis)
    sum1 = 0
    numa1 = list(numDis)
    rate1 = [numa1[0]]
    for i in range(1, len(numa1)):
        sum1 += numa1[i]
    for i in range(1, len(numa1)):
        rate1.append(numa1[i] / sum1)
    print(rate1)
    # for i in range(len(a)):
    #     a[i] = al
    studyrate = [0 for i in range(6)]
    while True:
        pre1, rec1, pre2, rec2, now = causalDiscovery(dataR.values,trueR,a,numDis)
        nowDis = [0, 0, 0, 0, 0, 0]
        for i in now:
            for j in now[i]:
                nowDis[abs(j[1])]+=1
        print(nowDis)
        sum2 = 0
        numa2 = list(nowDis)
        rate2 = [numa2[0]]
        for i in range(1, len(nowDis)):
            sum2 += numa2[i]
        for i in range(1, len(nowDis)):
            rate2.append(numa2[i] / sum2)
        print(rate2)
        break
    return pre1, rec1, pre2, rec2

if __name__ == '__main__':
    pres1 = []
    recs1 = []
    pres2 = []
    recs2 = []
    files = 10
    for num1 in range(files):
        print(num1+1,'/{}'.format(files))
        pre1, rec1, pre2, rec2 = main(num1,0.2)
        pres1.append(pre1)
        recs1.append(rec1)
        pres2.append(pre2)
        recs2.append(rec2)
    print(pres1)
    print(recs1)
    print(pres2)
    print(recs2)
    print(sum(pres1) / len(pres1))
    print(sum(recs1) / len(recs1))
    print(sum(pres2) / len(pres2))
    print(sum(recs2) / len(recs2))
