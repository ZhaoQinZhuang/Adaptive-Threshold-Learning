import os
import pickle
import numpy
from mpi4py import MPI
from tigtamite import data_processing as pp
from tigtamite.independence_tests import ParCorr
from tigtamite.pcmci import PCMCI
COMM = MPI.COMM_WORLD
def causalDiscoverySmall(data,trueR,a,parcor,numDis):
    global pre1,rec1,pre2,rec2, all_results
    verbosity = -1
    def  testPC(now,trueR):
        # print(now)
        # print(trueR)
        TP,P1,P2 = 0,0,0
        for i in now:
            l1 = now[i]
            for j in l1:
                if j in trueR[i]:
                    TP += 1
                P1 += 1
        for i in trueR:
            P2 += len(trueR[i])
        return TP/P1,TP/P2

    def split(container, count):
        return [container[_i::count] for _i in range(count)]
    def run_pc_stable_parallel(j):
        pcmci_of_j = PCMCI(
            dataframe=dataframe,
            cond_ind_test=cond_ind_test,
            verbosity=verbosity)
        parents_of_j = pcmci_of_j.run_pc_stable(
            selected_links=selected_links[j],
            tau_min=tau_min,
            tau_max=tau_max,
            pc_alpha=pc_alpha,
            a = a)
        return j, pcmci_of_j, parents_of_j

    def run_mci_parallel(j, pcmci_of_j, all_parents):
        results_in_j = pcmci_of_j.run_mci(
            selected_links=selected_links[j],
            tau_min=tau_min,
            tau_max=tau_max,
            parents=all_parents,
            max_conds_px=max_conds_px,
        )
        return j, results_in_j

    T, N = data.shape
    var_names = ['X0', 'X1', 'X2', 'X3']
    dataframe = pp.DataFrame(data, var_names=var_names)
    selected_variables = list(range(N))
    pc_alpha = 0.2
    tau_max = 3
    tau_min = 0
    max_conds_dim = None
    max_conds_px = None
    selected_links = {n: {m: [(i, -t) for i in range(N) for \
                              t in range(tau_min, tau_max)] if m == n else [] for m in range(N)} for n in range(N)}
    alpha_level = 0.05
    cond_ind_test = ParCorr()
    file_name = os.path.expanduser('~') + '/test_results.dat'
    if COMM.rank == 0:
        if verbosity > -1:
            print("## Running PC algorithm ##")
        splitted_jobs = split(selected_variables, COMM.size)
    else:
        splitted_jobs = None
    scattered_jobs = COMM.scatter(splitted_jobs, root=0)
    results = []
    for j in scattered_jobs:
        (j, pcmci_of_j, parents_of_j) = run_pc_stable_parallel(j)
        results.append((j, pcmci_of_j, parents_of_j))
    results = MPI.COMM_WORLD.gather(results, root=0)
    if COMM.rank == 0:
        all_parents = {}
        pcmci_objects = {}
        for res in results:
            for (j, pcmci_of_j, parents_of_j) in res:
                all_parents[j] = parents_of_j[j]
                pcmci_objects[j] = pcmci_of_j
        if verbosity > -1:
            # print("## Resulting condition sets:")
            for j in [var for var in all_parents.keys()]:
                pcmci_objects[j]._print_parents_single(j, all_parents[j],
                                                       pcmci_objects[j].val_min[j],
                                                       None)
        pre1,rec1 =  testPC(all_parents,trueR)
        numDisNow = [0 for i in range(tau_max)]
        for i in all_parents:
            for j in all_parents[i]:
                numDisNow[abs(j[1])] += 1
        if verbosity>-1:
            print(numDisNow)


        if verbosity >-1:
            print("## Running MCI algorithm ##")
        for i in range(1, COMM.size):
            COMM.send((all_parents, pcmci_objects), dest=i)
    else:
        (all_parents, pcmci_objects) = COMM.recv(source=0)
    scattered_jobs = COMM.scatter(splitted_jobs, root=0)
    results = []
    for j in scattered_jobs:
        (j, results_in_j) = run_mci_parallel(j, pcmci_objects[j], all_parents)
        results.append((j, results_in_j))
    results = MPI.COMM_WORLD.gather(results, root=0)
    if COMM.rank == 0:
        all_results = {}
        for res in results:
            for (j, results_in_j) in res:
                for key in results_in_j.keys():
                    if results_in_j[key] is None:
                        all_results[key] = None
                    else:
                        if key not in all_results.keys():
                            if key == 'p_matrix':
                                all_results[key] = numpy.ones(results_in_j[key].shape)
                            else:
                                all_results[key] = numpy.zeros(results_in_j[key].shape, dtype=results_in_j[key].dtype)
                        all_results[key][:, j, :] = results_in_j[key][:, j, :]
        p_matrix = all_results['p_matrix']
        val_matrix = all_results['val_matrix']
        conf_matrix = all_results['conf_matrix']
        sig_links = (p_matrix <= alpha_level)
        now = {}
        for j in selected_variables:

            links = dict([((p[0], -p[1]), numpy.abs(val_matrix[p[0],
                                                               j, abs(p[1])]))
                          for p in zip(*numpy.where(sig_links[:, j, :]))])

            # Sort by value
            sorted_links = sorted(links, key=links.get, reverse=True)
            n_links = len(links)
            string = ("    Variable %s has %d "
                      "link(s):" % (var_names[j], n_links))
            for p in sorted_links:
                string += ("\n        (%s %d)" %
                           (var_names[p[0]], p[1]))
            if verbosity>-1:
                print(string)
            now[j] = sorted_links
        # print(now,'\n',trueR)
        pre2, rec2 = testPC(now, trueR)
    return pre1, rec1, pre2, rec2

def causalDiscovery(data,trueR,a,numDis):
    global pre1,rec1,pre2,rec2, all_results, now
    verbosity = -1
    def  testPC(now,trueR):
        # print(now)
        # print(trueR)
        TP,P1,P2 = 0,0,0
        for i in now:
            l1 = now[i]
            for j in l1:
                if j in trueR[i]:
                    TP += 1
                P1 += 1
        for i in trueR:
            P2 += len(trueR[i])
        return TP/P1,TP/P2

    def split(container, count):
        return [container[_i::count] for _i in range(count)]
    def run_pc_stable_parallel(j):
        pcmci_of_j = PCMCI(
            dataframe=dataframe,
            cond_ind_test=cond_ind_test,
            verbosity=verbosity)
        parents_of_j = pcmci_of_j.run_pc_stable(
            selected_links=selected_links[j],
            tau_min=tau_min,
            tau_max=tau_max,
            pc_alpha=pc_alpha,
            a = a)
        return j, pcmci_of_j, parents_of_j

    def run_mci_parallel(j, pcmci_of_j, all_parents):
        results_in_j = pcmci_of_j.run_mci(
            selected_links=selected_links[j],
            tau_min=tau_min,
            tau_max=tau_max,
            parents=all_parents,
            max_conds_px=max_conds_px,
        )
        return j, results_in_j

    T, N = data.shape
    var_names = ['X0', 'X1', 'X2', 'X3','X4','X5','x6','X7','X8','X9']
    dataframe = pp.DataFrame(data, var_names=var_names)
    selected_variables = list(range(N))
    pc_alpha = 0.2
    tau_max = 6
    tau_min = 1
    max_conds_dim = None
    max_conds_px = None
    selected_links = {n: {m: [(i, -t) for i in range(N) for \
                              t in range(tau_min, tau_max)] if m == n else [] for m in range(N)} for n in range(N)}
    alpha_level = 0.05
    cond_ind_test = ParCorr()
    file_name = os.path.expanduser('~') + '/test_results.dat'
    if COMM.rank == 0:
        if verbosity > -1:
            print("## Running PC algorithm ##")
        splitted_jobs = split(selected_variables, COMM.size)
    else:
        splitted_jobs = None
    scattered_jobs = COMM.scatter(splitted_jobs, root=0)
    results = []
    for j in scattered_jobs:
        (j, pcmci_of_j, parents_of_j) = run_pc_stable_parallel(j)
        results.append((j, pcmci_of_j, parents_of_j))
    results = MPI.COMM_WORLD.gather(results, root=0)
    if COMM.rank == 0:
        all_parents = {}
        pcmci_objects = {}
        for res in results:
            for (j, pcmci_of_j, parents_of_j) in res:
                all_parents[j] = parents_of_j[j]
                pcmci_objects[j] = pcmci_of_j
        if verbosity > -1:
            # print("## Resulting condition sets:")
            for j in [var for var in all_parents.keys()]:
                pcmci_objects[j]._print_parents_single(j, all_parents[j],
                                                       pcmci_objects[j].val_min[j],
                                                       None)
        pre1,rec1 =  testPC(all_parents,trueR)
        numDisNow = [0 for i in range(tau_max)]
        for i in all_parents:
            for j in all_parents[i]:
                numDisNow[abs(j[1])] += 1
        if verbosity>-1:
            print(numDisNow)


        if verbosity >-1:
            print("## Running MCI algorithm ##")
        for i in range(1, COMM.size):
            COMM.send((all_parents, pcmci_objects), dest=i)
    else:
        (all_parents, pcmci_objects) = COMM.recv(source=0)
    scattered_jobs = COMM.scatter(splitted_jobs, root=0)
    results = []
    for j in scattered_jobs:
        (j, results_in_j) = run_mci_parallel(j, pcmci_objects[j], all_parents)
        results.append((j, results_in_j))
    results = MPI.COMM_WORLD.gather(results, root=0)
    if COMM.rank == 0:
        all_results = {}
        for res in results:
            for (j, results_in_j) in res:
                for key in results_in_j.keys():
                    if results_in_j[key] is None:
                        all_results[key] = None
                    else:
                        if key not in all_results.keys():
                            if key == 'p_matrix':
                                all_results[key] = numpy.ones(results_in_j[key].shape)
                            else:
                                all_results[key] = numpy.zeros(results_in_j[key].shape, dtype=results_in_j[key].dtype)
                        all_results[key][:, j, :] = results_in_j[key][:, j, :]
        p_matrix = all_results['p_matrix']
        val_matrix = all_results['val_matrix']
        conf_matrix = all_results['conf_matrix']
        sig_links = (p_matrix <= alpha_level)
        now = {}
        for j in selected_variables:

            links = dict([((p[0], -p[1]), numpy.abs(val_matrix[p[0],
                                                               j, abs(p[1])]))
                          for p in zip(*numpy.where(sig_links[:, j, :]))])

            # Sort by value
            sorted_links = sorted(links, key=links.get, reverse=True)
            n_links = len(links)
            string = ("    Variable %s has %d "
                      "link(s):" % (var_names[j], n_links))
            for p in sorted_links:
                string += ("\n        (%s %d)" %
                           (var_names[p[0]], p[1]))
            if verbosity>-1:
                print(string)
            now[j] = sorted_links
        # print(now,'\n',trueR)
        pre2, rec2 = testPC(now, trueR)
    return pre1, rec1, pre2, rec2,now






