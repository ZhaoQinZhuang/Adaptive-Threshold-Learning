from tools import dataProcessNew, ShowTrueC, readdata
from functions import causalDiscovery, causalDiscoverySmall


def main(dn):
    message = -100   #控制台输出信息冗余度
    dn =dn                              #文件编号
    path = 'D:\\科研\\实验\\4-3\\'      #数据路径
    dataPath = path + 'data' + str(dn) + '.csv'

    realDAG,trueR = ShowTrueC(message,path)  # 查看真实关系
    dataR = readdata(dataPath, message)  # 读取数据集
    aMax ,aMin = 0.01,0.01
    dataP,a,parcor,estDis = dataProcessNew(dataR,path,dn,aMax,aMin,3,message)#参数初始化
    print(a)
    print(estDis)
    while True:
        return causalDiscoverySmall(dataR.values,trueR,a,parcor,estDis)
        break

if __name__ == '__main__':
    pres1 = []
    recs1 = []
    pres2 = []
    recs2 = []
    for num1 in range(1):
        print(num1)
        pre1,rec1,pre2,rec2 = main(num1)
        pres1.append(pre1)
        recs1.append(rec1)
        pres2.append(pre2)
        recs2.append(rec2)
    print(pres1)
    print(recs1)
    print(pres2)
    print(recs2)
    print(sum(pres1)/len(pres1))
    print(sum(recs1)/len(recs1))
    print(sum(pres2)/len(pres2))
    print(sum(recs2)/len(recs2))

