import pandas as pd
import numpy as np
from tools import ShowTrueC, test, dataProcessNew1, readdata, purntest
from causallearn.search.FCMBased import lingam
np.set_printoptions(suppress=True)

def main(dn,lags,apre = None):
    path = 'D:\\科研\\实验\\4-3\\'
    dataPath = path + 'data' + str(dn) + '.csv'
    X = pd.read_csv(dataPath, header=None, engine='python')
    realDAG,trueR = ShowTrueC(-11,path)
    dataR = readdata(dataPath, -1)  # 读取数据集
    a,numDis = dataProcessNew1(dataR, path, dn, lagMaxh=3, message=-5)
    # print(a,numDis)
    if apre is not None:
        for i in range(len(a)):
            a[i]=apre
    model = lingam.VARLiNGAM(lags=lags)
    model.fit(X)
    results = model.adjacency_matrices_
    # print(results)
    now = {}
    for i in range(len(results[0])):
        now[i] = []
    for lag in range(len(results)):
        res = results[lag]
        for i in range(len(res)):
            for j in range(len(res)):
                # pval = purntest(800, res[i][j])
                if res[i][j]>a[lag]:
                # if pval < a[lag]:
                    now[i].append((j, -lag))
    es = test(now,trueR)
    if es[0]<1 or es[1]<1:
        print(now)
        print(trueR)
        print(a)
        print(results)
    es.append(len(results))
    return es

if __name__ == '__main__':
    n=1
    lenths = 0
    pres = []
    recs = []
    lags = 3
    apre = None
    for dn in range(n):
        print(dn+1,'/{}'.format(n))
        pre,rec,lenth = main(dn,lags,apre)
        pres.append(pre)
        recs.append(rec)
        lenths+=lenth
    print(pres)
    print(recs)
    print(sum(pres) / len(pres))
    print(sum(recs) / len(recs))
    print(lenths/n)
    print(apre)