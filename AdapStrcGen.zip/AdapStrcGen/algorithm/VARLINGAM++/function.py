#   -*- coding:utf-8 -*-
#   项目名：TCLBL
#   文件名：function.py
#   作者：赵秦壮
#   新建时间：2023/7/21-20:57

def varLingamPurn(estDis,results,a):
    print(a)
    print(estDis)
    # estDis = [0, 12, 2, 3, 1, 1]
    # print(estDis)
    now = {}
    nowDis = [0,0,0,0,0,0]
    flag1 = 0
    while True:
        for i in range(len(nowDis)):
            nowDis[i] = 0
        for i in range(len(results[0])):
            now[i] = []
        for lag in range(len(results)):
            res = results[lag]
            for i in range(len(res)):
                for j in range(len(res)):
                    # pval = purntest(800,res[i][j])
                    if res[i][j] > a[lag]:
                        # if pval<a[lag]:
                        now[i].append((j, -lag))
                        nowDis[lag]+=1
        # print('now半',now)
        # print(nowDis)
        flag = 1
        for i in range(1,6):
            if estDis[i] > nowDis[i]:
                # print('在改小延迟',i)
                flag=0
                changeN = 0
                resC = results[i]
                for j in range(len(resC)):
                    for k in range(len(resC[j])):
                        if i==1 or (i!=1 and j!=k):
                            shu = abs(resC[j][k])
                            if a[i] > shu > changeN and (j,-i) not in now[k]:
                                # print(j,k,'延迟',i,shu)
                                changeN = shu
                # print(i,'延迟改为',changeN)
                a[i] = changeN-0.0000001
                # print(a)
            if estDis[i] < nowDis[i]:
                # print('在改大延迟',i)
                flag=0
                changeN=0.9
                resC=results[i]
                for j in range(len(resC)):
                    for k in range(len(resC[j])):
                        shu = abs(resC[j][k])
                        if a[i] < shu < changeN and (j,-i) not in now[k]:
                            changeN = shu
                # print(i, '延迟改为', changeN)
                # print(j, k, '延迟', i, shu)
                a[i] = changeN
        # print(nowDis)
        if flag:
            print(a)
            break
        flag1+=1
        if flag1>10:
            print(a)
            break
    # print('now',now)
    # print(estDis)
    # print(nowDis)
    return now
