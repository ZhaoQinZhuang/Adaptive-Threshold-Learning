import pandas as pd
import numpy as np
from tools import ShowTrueC, test, dataProcessNew1, readdata, purntest
from causallearn.search.FCMBased import lingam
from function import varLingamPurn
np.set_printoptions(suppress=True)

def main(dn,lags,apre = None):
    path = 'D:\\科研\\实验\\10-5\\'
    dataPath = path + 'data' + str(dn) + '.csv'
    X = pd.read_csv(dataPath, header=None, engine='python')
    realDAG,trueR = ShowTrueC(-11,path)
    dataR = readdata(dataPath, -1)  # 读取数据集
    a,numDis = dataProcessNew1(dataR, path, dn, lagMaxh=5, message=-5)
    if apre is not None:
        for i in range(len(a)):
            a[i]=apre
    model = lingam.VARLiNGAM(lags=lags)
    model.fit(X)
    results = model.adjacency_matrices_
    # print(results)

    now = varLingamPurn(numDis,results,a)
    es = test(now,trueR)
    # if es[0]<1 or es[1]<1:
    #     print(now)
    #     print(trueR)
    #     print(a)
    es.append(len(results))
    return es

if __name__ == '__main__':
    n=10
    lenths = 0
    pres = []
    recs = []
    lags = 5
    apre = None
    for dn in range(n):
        print(dn,'\/{}'.format(n))
        pre,rec,lenth = main(dn,lags,apre)
        pres.append(pre)
        recs.append(rec)
        lenths+=lenth
    print(pres)
    print(recs)
    mp,mr = sum(pres) / len(pres),sum(recs) / len(recs)
    print(mp)
    print(mr)
    f1 = 2*(mp*mr)/(mp+mr)
    print(f1)