# 赵秦壮
# 开发时间：2022/11/10  10:34
from tools import ShowTrueC,readdata,dataProcess
from functions import skeleton

dataPath = 'D:\\file\\研究生\\科研\\experiment\\data4Nodes\\data0.csv'
message = -1                             #提示
lagMax = None

if __name__ == '__main__':
    ShowTrueC(message)                          #查看真实关系
    dataY = readdata(dataPath,message)          #读取数据集
    lagMax,alpha,data = dataProcess(dataY)      #数据预处理
    ske = skeleton(data,lagMax,alpha,message)   #骨架学习

