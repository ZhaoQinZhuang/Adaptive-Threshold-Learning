# 赵秦壮
# 开发时间：2022/11/17  17:26

import numpy as np
import pandas as pd
import math
from scipy.stats import norm
import pylab
pylab.mpl.rcParams['font.sans-serif'] = ['SimHei']
import matplotlib.pyplot as plt
import networkx as nx
import itertools

def plot(graph, labels: list, path=None,ncolors=None,edge=None ,name=''):
    col = int(labels[0].split('-')[1])+1
    row = len(graph)/col
    plt.rcParams['figure.figsize'] = (col+1, row+1)
    plt.cla()
    edgeList = []
    dedgeList = []
    G = nx.DiGraph()  # 创建空有向图
    G.add_nodes_from(labels)
    for i in range(len(graph)):
        for j in range(i):
            if graph[i][j] or graph[j][i]:
                if graph[i][j] and graph[j][i]:
                    edgeList.append((labels[i],labels[j]))
                elif graph[i][j]:
                    dedgeList.append((labels[i],labels[j]))
                else:
                    dedgeList.append((labels[j],labels[i]))
    G.add_edges_from(edgeList+dedgeList)
    if ncolors is None:
        ncolors = ['red']
    nsize = 800
    pos = {}
    # pos = nx.circular_layout(G)
    a,b,c = 0,0.08,0.08
    a,b,c = 0,0,0
    for node in labels:
        nrow,ncol = node.split('-')
        pos[node] = [col - int(ncol),int(nrow)+0.5+a]
        a += b
        b+=c
    nx.draw_networkx_nodes(G,pos,node_size=nsize,node_color='red')
    nx.draw_networkx_edges(G,pos,edgeList,arrows=False,node_size=nsize)
    nx.draw_networkx_edges(G,pos,dedgeList,arrows=True,node_size=nsize)
    nx.draw_networkx_labels(G,pos)
    plt.title(name,y=-0.1, bbox={"edgecolor": "black", "facecolor": "lightcyan"})
    plt.axis('off')
    plt.show()
    return  0
def parr_ci_test(suffstat, n,x, y, S, rnum = 0):
    """条件独立性检验"""
    C = suffstat
    cut_at = 0.9999999
    # ------ 偏相关系数 ------
    # S中没有点
    if len(S) == 0:
        r = C[x, y]
    # S 中只有一个点，即一阶偏相关系数
    elif len(S) == 1:
        r = ((C[x, y] - C[x, S] * C[y, S]) / math.sqrt((1 - math.pow(C[y, S], 2)) * (1 - math.pow(C[x, S], 2))))[0]
    else:
        m = C[np.ix_([x] + [y] + S, [x] + [y] + S)]
        PM = np.linalg.pinv(m)
        r = -1 * PM[0, 1] / math.sqrt(abs(PM[0, 0] * PM[1, 1]))
    r = min(cut_at, max(-1 * cut_at, r))
    # res =  (math.sqrt(n - len(S) - 2) * r) / math.sqrt(1-math.pow(r,2))
    if rnum:
        return round(r,4)

    # # Fisher’s z-transform
    res = math.sqrt(n - len(S) - 3) * .5 * math.log1p((2 * r) / (1 - r))
    # # Φ^{-1}(1-α/2)
    # return 2 * (1 - norm.cdf(abs(res)))
    return 2 * (1 - norm.cdf(abs(res)))

def purntest(n,v):
    cut_at = 0.9999999
    # ------ 偏相关系数 ------
    # S中没有点

    r = min(cut_at, max(-1 * cut_at, v))
    res = math.sqrt(n - 3) * .5 * math.log1p((2 * r) / (1 - r))
    return 2 * (1 - norm.cdf(abs(res)))

def ShowTrueC(message,path):
    f1 = open(path + 'TrueC.txt'    , 'r', encoding='utf8', newline='')
    f2 = open(path + 'TrueCd.txt', 'r', encoding='utf8', newline='')
    txt1 = f1.readline()
    txt2 = f2.readline()
    if message > 2:
        if message >0:
            print("******真实关系如下：to 结果  from  [原因，延迟，大小]   [原因，延迟，大小]*********************************************")
        else:
            print("******真实关系**************************************************************************************************")
        while txt1:
            print(txt1, end='')
            txt1 = f1.readline()
        print("***************************************************************************************************************")
    if message > -1000:
        rownum = 0
        lagmax = 0
        list = []
        while txt2:
            rownum +=1
            data = txt2.split(',')
            for i in range(0,len(data),3):
                list.append((rownum-1,int(data[i]),int(data[i+1]),float(data[i+2])))
                lagmax = max(lagmax,abs(int(data[i+1])))
            txt2 = f2.readline()
        dic = {}
        for i in list:
            if i[0] in dic:
                dic[i[0]].append((i[1], i[2]))
            else:
                dic[i[0]] = [(i[1],i[2])]
        lenth = rownum*(lagmax+1)
        G = [[0 for i in range(lenth)] for i in range(lenth)]
        for t in list:
            end,start,lagt,size = t
            lagt = abs(lagt)
            for i in range(lagmax-lagt+1):
                G[start+i*rownum][end+(lagt+i)*rownum] = 1
        labels = labelsGen(rownum, lagmax+1)
        if message > -2:
            print(labels)
        if message >-1:
            plot(G,labels,name='真实图')
        return G,dic
def DFS(G,i,j,sets):#找点
    for k in range(len(G[i])):
        if G[i][k] and sets[k] == 0 and k!=j:
            sets[k] = True
            DFS(G,k,j,sets)
def readdata(file_path,message):
    data = pd.read_csv(file_path, header=None, engine='python')
    if message >1:
        print()
        print()
        print("****数据集展示***************************************************************************************************")
        print(data)
        print("***************************************************************************************************************")
    return data
def dataProcess(data,lagMaxh = None,message = 0):
    dataA = data.values
    data1 = dataA.tolist()
    # print(data1)
    data2 = [[] for i in range(len(data1))]
    n,l = len(data1[0]),len(data1)-12
    datan = np.array(data1)
    lagMax = 0
    anum = [0 for i in range(13)]

    anum[0] = 0
    for i in range(n):
        lagMaxS = 0#自相关延迟
        datai = list(datan.T[i])
        dataij = [[] for m in range(12)]#延迟
        for j in range(12):
            for k in range(l):
                dataij[j].append(datai[k+j])
        dataif = pd.DataFrame(data=dataij).T
        corArray = dataif.corr().values
        S = []
        for m in range(0,11):
            result = parr_ci_test(corArray, l, 0, m + 1, S)
            # print("延迟:",m+1,S,"偏相关:",result)
            if result > 0.01:
                lagMax = max(lagMax,len(S))
                lagMaxS = max(lagMaxS,len(S))
                break
            anum[m+1]+=1
            S.append(m+1)
        data2 = list(data1)#自相关未处理
        if lagMaxh is not None:
            lagMax = lagMaxh
        #自相关性缓解
        # down = pow(0.01, 1 / (lagMaxS+1))
        # sumf = 0
        # for j in datai:
        #     sumf+=j
        # start = round(sumf/len(datai),6)
        # data2[0].append(round(datai[0]-(down*start + (1-down) * datai[0]),6))
        # for j in range(1,len(datai)):
        #     data2[j].append(round(datai[j]-(down*datai[j-1] + (1-down) * datai[j]),6),)
    # print(anum)
    a = [0 for i in range(lagMax+1)]
    a[0] = 0.15
    sum = (1+lagMax)*lagMax/2
    for i in range(1,len(a)):
        a[i] = a[i-1]-0.1*(i/sum)
    for i in range(len(a)):
        a[i] = round(a[i],3)
    # print(len(data2))
    l += 12
    # print(l)
    for i in range(l-lagMax):                       #数据扩展
        for j in range(1,lagMax+1):
            data2[i] += data2[i+j]
    # print(data2)
    for i in range(lagMax):
        data2.pop(l-lagMax)
    # print(data2)
    # print(len(data2[995]))
    dataend = pd.DataFrame(data=data2)
    dataend.to_csv('D:\\file\\研究生\\科研\\experiment\\dataend.csv')
    # print('anumchuli',anum)
    for i in range(lagMax):
        anum[i+1]*=(lagMax-i)
    for i in range(2,lagMax+1):
        # anum[i]=int(anum[i]/2)
        anum[i]=math.ceil(anum[i]/2)
        anum[1]+=anum[i]
    if message>0:
        print('toolanum',anum)
    return lagMax,a,dataend.corr().values,len(dataend),anum[0:lagMax+1]

def dataProcessNew(data,dataPath,dn,lagMaxh = None,message = 0):
    lagMaxh = 6
    dataA = data.values
    data1 = dataA.tolist()
    data2 = [[] for i in range(len(data1))]
    n, l = len(data1[0]), len(data1)
    datan = np.array(data1)
    lagMax = 0
    anum = [0 for i in range(13)]
    if lagMaxh is not None:
        lagMax = lagMaxh
    data2 = list(data1)

    for i in range(l - lagMax):  # 数据扩展
        for j in range(1, lagMax + 1):
            data2[i] += data2[i + j]
    # print(data2)
    for i in range(lagMax):
        data2.pop(l - lagMax)
    # print(data2)
    dataend = pd.DataFrame(data=data2)
    # dataend.to_csv(dataPath + 'dataend' + str(dn) + '.csv')
    # print(dataend)
    # print(len(dataend))
    # print(len(dataend[0]))
    corrArray = dataend.corr().values
    avecor = []
    flag1, flag2 = n * lagMax, n * lagMax
    for i in range(lagMax + 1):
        if message > -1:
            print('lag=', i)
        number = 0
        sum = 0
        for j in range(n):
            if message > -1:
                print('from=', flag1 + j, end='\t')
            for k in range(n):
                if message > -1:
                    print('to=', flag2 + k, end='\t')
                sum += abs(corrArray[flag1 + j][flag2 + k])
                number += 1
                if message > -1:
                    print('corr=', corrArray[flag1 + j][flag2 + k], end='\t')
            if message > -1:
                print(' ')
        flag2 -= n
        avecor.append(sum / number)
    if message > -1:
        print(avecor)
    # 参数初始化
    aNum = []
    corMax = max(avecor)
    adjRange = corMax - min(avecor)
    # ave = 0
    # for i in range(len(avecor)):
    #     ave += avecor[i]
    # ave /= len(avecor)
    # ave = round(ave/100,4)
    # print(ave)
    for i in range(lagMax + 1):
        aNum.append(round(0.2 - (corMax - avecor[i]) / adjRange * 0.1, 4))
    if message > -2:
        print(aNum)
    # 数量分布
    numDis = [0 for i in range(lagMax)]
    parrcors = []
    for i in range(n):
        parrcor = []
        S = []
        for j in range(lagMax + 1):
            parrcor.append(parr_ci_test(corrArray, l, flag1 + i, flag1 + i - n * j, S, rnum=1))
            if j != 0:
                S.append(flag1 + i - n * j)
        parrcors.append(parrcor)
    for i in range(n):
        a = parrcors[i]
        # print(i, a)
        # if abs(a[1]) < 0.95 and abs(a[2]<0.15):#仅有自相关
        if abs(a[1]) < 0.99 and abs(a[2]) + abs(a[3]) < 0.5:  # 仅自相关或仅外生变量
            meanr = 0
            meane = 0
            for k in range(2, len(a)):
                meanr += abs(a[k])
                meane += a[k]
            meanr = round(meanr / 5, 4)
            meane = round(abs(meane / 5), 4)
            if meanr < 0.09 and meane < 0.09:  # 仅自相关
                # print(i,a)
                # print(meanr,meane)
                numDis[1] += 1
                continue
            else:  # 仅外生变量
                # print(meanr)
                while True:
                    if meanr > 0.13:
                        numDis[1] += 1
                        meanr -= 0.14
                    elif meanr > 0.1:
                        numDis[2] += 1
                        meanr -= 0.1
                    elif meanr > 0.04:
                        numDis[3] += 1
                        meanr -= 0.5
                    else:
                        break
                continue
        else:  # 都有
            # print(i,a)
            numDis[1] += 1
            if abs(a[2]) > 0.7:  # 有链
                a[2] = abs(a[2]) - 0.7
                while True:
                    if a[2] > 0.2:
                        numDis[1] += 1
                        a[2] -= 0.2
                    elif a[2] > 0.1:
                        numDis[2] += 1
                        a[2] -= 0.1
                    elif a[2] > 0.05:
                        numDis[4] += 1
                        a[2] -= 0.05
                    elif a[2] > 0.01:
                        numDis[5] += 1
                        a[2] -= 1
                    else:
                        break
            else:  # 无链
                # print(i,a)
                a[2] = abs(a[2])
                while True:
                    if a[2] > 0.3:
                        numDis[1] += 1
                        a[2] -= 0.3
                    elif a[2] > 0.25:
                        numDis[2] += 1
                        a[2] -= 0.2
                    elif a[2] > 0.05:
                        numDis[3] += 1
                        a[2] -= 1
                    elif a[2] > 0.03:
                        numDis[4] += 1
                        a[2] -= 1
                    elif a[2] > 0.01:
                        numDis[5] += 1
                        a[2] -= 1
                    else:
                        break
    numDis = [0,12,2,3,1,1]
    return aNum, numDis
def dataProcessNew1(data,dataPath,dn,lagMaxh = None,message = 0):
    lagMaxh = 6
    dataA = data.values
    data1 = dataA.tolist()
    data2 = [[] for i in range(len(data1))]
    n, l = len(data1[0]), len(data1)
    datan = np.array(data1)
    lagMax = 0
    anum = [0 for i in range(13)]
    if lagMaxh is not None:
        lagMax = lagMaxh
    data2 = list(data1)


    for i in range(l-lagMax):                       #数据扩展
        for j in range(1,lagMax+1):
            data2[i] += data2[i+j]
    # print(data2)
    for i in range(lagMax):
        data2.pop(l-lagMax)
    # print(data2)
    dataend = pd.DataFrame(data=data2)
    # dataend.to_csv(dataPath + 'dataend' + str(dn) + '.csv')
    # print(dataend)
    # print(len(dataend))
    # print(len(dataend[0]))
    corrArray = dataend.corr().values
    avecor = []
    flag1,flag2 = n * lagMax,n * lagMax
    for i in range(lagMax+1):
        if message > -1:
            print('lag=',i)
        number = 0
        sum = 0
        for j in range(n):
            if message > -1:
                print('from=',flag1+j,end='\t')
            for k in range(n):
                if message > -1:
                    print('to=', flag2 + k,end='\t')
                sum += abs(corrArray[flag1+j][flag2+k])
                number += 1
                if message > -1:
                    print('corr=',corrArray[flag1+j][flag2+k],end='\t')
            if message > -1:
                print(' ')
        flag2 -= n
        avecor.append(sum/number)
    if message > -1:
        print(avecor)
    #参数初始化
    aNum = []
    corMax = max(avecor)
    adjRange = corMax - min(avecor)
    # ave = 0
    # for i in range(len(avecor)):
    #     ave += avecor[i]
    # ave /= len(avecor)
    # ave = round(ave/100,4)
    # print(ave)
    for i in range(lagMax+1):
        aNum.append(round(0.34 -(corMax-avecor[i])/adjRange*0.04,4))
    if message>-2:
        print(aNum)
    #数量分布
    numDis = [0 for i in range(lagMax)]
    parrcors = []
    for i in range(n):
        parrcor = []
        S = []
        for j in range(lagMax+1):
            parrcor.append(parr_ci_test(corrArray,l,flag1+i,flag1+i-n*j,S,rnum=1))
            if j!=0:
                S.append(flag1+i-n*j)
        parrcors.append(parrcor)
    for i in range(n):
        a = parrcors[i]
        # print(i, a)
        # if abs(a[1]) < 0.95 and abs(a[2]<0.15):#仅有自相关
        if abs(a[1]) < 0.99 and abs(a[2])+abs(a[3])<0.5:#仅自相关或仅外生变量
            meanr=0
            meane=0
            for k in range(2,len(a)):
                meanr+=abs(a[k])
                meane+=a[k]
            meanr = round(meanr/5,4)
            meane = round(abs(meane/5),4)
            if meanr<0.09 and meane <0.09:#仅自相关
                # print(i,a)
                # print(meanr,meane)
                numDis[1] += 1
                continue
            else:#仅外生变量
                # print(meanr)
                while True:
                    if meanr>0.13:
                        numDis[1]+=1
                        meanr-=0.14
                    elif meanr>0.1:
                        numDis[2]+=1
                        meanr-=0.1
                    elif meanr>0.04:
                        numDis[3]+=1
                        meanr-=0.5
                    else:
                        break
                continue
        else:#都有
            # print(i,a)
            numDis[1]+=1
            if abs(a[2])>0.7:#有链
                a[2] = abs(a[2])-0.7
                while True:
                    if a[2] >0.2:
                        numDis[1]+=1
                        a[2]-=0.2
                    elif a[2] >0.1:
                        numDis[2]+=1
                        a[2]-=0.1
                    elif a[2]>0.05:
                        numDis[4]+=1
                        a[2]-=0.05
                    elif a[2]>0.01:
                        numDis[5]+=1
                        a[2]-=1
                    else:break
            else:#无链
                # print(i,a)
                a[2] = abs(a[2])
                while True:
                    if a[2]>0.3:
                        numDis[1]+=1
                        a[2]-=0.3
                    elif a[2]>0.25:
                        numDis[2]+=1
                        a[2]-=0.2
                    elif a[2]>0.05:
                        numDis[3]+=1
                        a[2]-=1
                    elif a[2]>0.03:
                        numDis[4]+=1
                        a[2]-=1
                    elif a[2]>0.01:
                        numDis[5]+=1
                        a[2]-=1
                    else:break
    return aNum,numDis
def labelsGen(num,lag):
    labels = []
    for i in range(lag):
        for j in range(num):
            labels.append(str(j)+'-'+str(lag - i - 1))
    return labels

def value(GTa,G):
    GT=GTa[0]

    TP,FP,TN,FN = 0,0,0,0
    for i in range(len(GT)):
        for j in range(len(GT)):
            if GT[i][j] == 1:
                GT[j][i] = 1
    # print(GT,'\n',G)
    for i in range(len(GT)):
        for j in range(i):
            if GT[i][j] == True:
                if G[i][j] == True:
                    TP+=1
                else:
                    FN+=1
            elif G[i][j] == False:
                TN+=1
            else:
                FP+=1
    # print(TP,FP,TN,FN)
    acc = (TN+TP)/(TP+TN+FP+FN)
    pre = TP/(TP+FP)
    rec = TP/(TP+FN)
    F1 = 2*(pre*rec)/(pre+rec)
    return acc,pre,rec,F1

def  test(now,trueR):
    TP,P1,P2 = 0,0,0
    for i in now:
        l1 = now[i]
        for j in l1:
            if j in trueR[i]:
                TP += 1
            P1 += 1
    for i in trueR:
        P2 += len(trueR[i])
    return [TP/P1,TP/P2]

def adjst(a,disest,disres):
    pass