# Attribution

The files `data_dillingen.csv`, `data_kempten.csv` and `data_lenggries.csv` contain river discharge data that has been downloaded from the Bavarian Environmental Agency (Bayerisches Landesamt für Umwelt, www.lfu.bayern.de) at https://www.gkd.bayern.de/en/rivers/discharge.