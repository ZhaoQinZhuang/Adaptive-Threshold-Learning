Evaluations
================================================
In this section, we would like to introduce evaluations in causal-learn.


Contents:

.. toctree::
    :maxdepth: 2


