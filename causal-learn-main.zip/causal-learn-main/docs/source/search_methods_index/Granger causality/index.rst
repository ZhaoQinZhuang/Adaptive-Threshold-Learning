.. _granger:

Granger causality
===================
In this section, we would like to introduce methods in Granger Causality. Now we have linear Granger Causality.


Contents:

.. toctree::
    :maxdepth: 2

    LinearGranger

